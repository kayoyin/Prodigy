INSTRUCTIONS TO USE THE TRANSLATION

TWO Folders available:
For now, in order to get the translated vectors, you still do need to run two different commands that will be explained below.
Midicsv folder is composed of all the folders from the top to "script"
and translate folder is the reamaining.


- In midicsv folder, you can check that there is a makefile, first "make", then you will see a "script" that you run like any executable. But before running the script, first put the midifile you wanna translate inside the folder music. Then run the script. Following this command, you will find inside the folder "csvs" the csv midi files, however the only csv that you want will be the "test.csv" which is the merged csv of all csv. (We don't have yet a script, but can easily add it, in order to move the new csv inside the folder translate)

- In translate folder, you will need to again "make", then you will see executable that are "translate"/"translateback"/"change", which are self-explanatory. And don't forget to change the code yourself inside the translate.cpp in order to get the printed version of the vector.
